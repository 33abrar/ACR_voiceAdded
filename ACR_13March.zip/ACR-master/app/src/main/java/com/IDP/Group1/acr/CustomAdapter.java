package com.IDP.Group1.acr;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GestureDetectorCompat;
import androidx.core.view.MotionEventCompat;

import java.util.List;
import java.util.zip.Inflater;


public class CustomAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private String[] items;
    int numberOfColumns;
    int numberOfRows;

    public CustomAdapter(Context context, String[] items) {
        this.context = context;
        this.items = items;
        inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        int numberOfColumns;
        int numberOfRows ;// Math.ceil(items.Count / numberOfColumns);
    }

    @Override
    public int getCount() {
        return items.length;
    }

    @Override
    public Object getItem(int i) {
        return items[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @SuppressLint("ViewHolder")
    @NonNull
    @Override
    public View getView(int position, @Nullable View view, @NonNull ViewGroup viewGroup) {
        if (view == null) {
            view = inflater.inflate(R.layout.floor_item, null);
        }
        final Button btn;
        btn = view.findViewById(R.id.item_btn);
        btn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                btn.setText("T");
                return true;
            }
        });
        return view;
    }
}
