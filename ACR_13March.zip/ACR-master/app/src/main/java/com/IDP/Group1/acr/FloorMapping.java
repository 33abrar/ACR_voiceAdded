package com.IDP.Group1.acr;


import android.os.Bundle;

import androidx.annotation.ColorInt;
import androidx.core.view.GestureDetectorCompat;
import androidx.core.view.MotionEventCompat;
import androidx.fragment.app.Fragment;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class FloorMapping extends Fragment {

	private GridView floor_grid;
	private Button set_btn;
	private int x_limit, y_limit, numColumns=6, rawWidth=50, count=0;
	public String[] items ={"Button1","Button2","Button3","Button4","Button5","Button6",
							"Button1","Button2","Button3","Button4","Button5","Button6",
							"Button1","Button2","Button3","Button4","Button5","Button6",
							"Button1","Button2","Button3","Button4","Button5","Button6",
							"Button1","Button2","Button3","Button4","Button5","Button6",
							"Button1","Button2","Button3","Button4","Button5","Button6"};
	public String[][] floor_value ={{"0","0","0","0","0","0"},
			{"0","0","0","0","0","0"},
			{"0","0","0","0","0","0"},
			{"0","0","0","0","0","0"},
			{"0","0","0","0","0","0"},
			{"0","0","0","0","0","0"}};

	private VelocityTracker mVelocityTracker = null;
	private static final String DEBUG_TAG = "Velocity";
	DisplayMetrics metrics;

	public FloorMapping() {
		// Required empty public constructor
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
							 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View V=inflater.inflate(R.layout.fragment_floor_mapping, container, false);
		floor_grid=V.findViewById(R.id.floor_grid);
		set_btn=V.findViewById(R.id.set_btn);
		floor_grid.setAdapter(new CustomAdapter(getContext(),items));
		floor_grid.setNumColumns(numColumns);
		//floor_grid.setColumnWidth(columnsWidth);
		metrics = getResources().getDisplayMetrics();

		//y_limit=
		floor_grid.setHorizontalSpacing(0);
		floor_grid.setVerticalSpacing(0);

		floor_grid.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View view, MotionEvent motionEvent) {
				x_limit=floor_grid.getColumnWidth()*floor_grid.getNumColumns();
				y_limit=(int)(Math.ceil(items.length/floor_grid.getNumColumns())*metrics.density*rawWidth);
				//int densityDpi = (int)(metrics.density * 160f);
				set_btn.setText(String.valueOf(x_limit)+" "+String.valueOf(y_limit));
				int index = motionEvent.getActionIndex();
				int action = motionEvent.getActionMasked();
				int pointerId = motionEvent.getPointerId(index);

				int x= (int) motionEvent.getX();
				int y= (int) motionEvent.getY();

				int row=(int)(x/floor_grid.getColumnWidth());
				int col=(int)(y/(metrics.density*rawWidth));
				set_btn.setText(String.valueOf(index)+" "+String.valueOf(row)+" "+String.valueOf(col));
				floor_value[row][col]="1";

				//set_btn.setText("T");
				/*switch(action) {
					case MotionEvent.ACTION_DOWN:
						if(mVelocityTracker == null) {
							// Retrieve a new VelocityTracker object to watch the
							// velocity of a motion.
							//mVelocityTracker = VelocityTracker.obtain();
						}
						else {
							// Reset the velocity tracker back to its initial state.
							mVelocityTracker.clear();
						}
						// Add a user's movement to the tracker.
						mVelocityTracker.addMovement(motionEvent);
						break;
					case MotionEvent.ACTION_MOVE:
						mVelocityTracker.addMovement(motionEvent);
						// When you want to determine the velocity, call
						// computeCurrentVelocity(). Then call getXVelocity()
						// and getYVelocity() to retrieve the velocity for each pointer ID.
						mVelocityTracker.computeCurrentVelocity(1000);
						// Log velocity of pixels per second
						// Best practice to use VelocityTrackerCompat where possible.
						//Log.d("", "X velocity: " + mVelocityTracker.getXVelocity(pointerId));
						//Log.d("", "Y velocity: " + mVelocityTracker.getYVelocity(pointerId));
						break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
						// Return a VelocityTracker object back to be re-used by others.
						mVelocityTracker.recycle();
						break;
				}*/
				//set_btn.setText("T");
				return false;
			}
		});
		set_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				//Toast.makeText(getContext(),floor_value.toString(),Toast.LENGTH_LONG).show();
				int i;
				set_btn.setText(floor_value[count][0]+floor_value[count][1]+floor_value[count][2]+floor_value[count][3]+floor_value[count][4]+floor_value[count][5]);
				count=(count+1)%6;
			}
		});
		return V;
	}
}
